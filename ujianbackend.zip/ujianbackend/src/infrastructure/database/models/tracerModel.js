const getTracerId = async (id) => {
  const sql = `SELECT * FROM tracer_barang WHERE id_tracer = ${id} `;

  const [data] = await koneksi.query(sql);
  return data;
};
