const getId = async (req, res) => {
  try {
    const id = req.params.id;
    const result = await getTracerId(id);
    return responSukses(res, 200, "success", "Data Tracer", result);
  } catch (error) {
    return responError(res, 500, error.message);
  }
};
