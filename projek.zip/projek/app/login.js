import { ambilDataUser } from "../service/storage.js";


const smallEmail = document.getElementById("smallEmail");
const smallPw = document.getElementById("smallPw");
const smallNoValid = document.getElementById("smallNoValid");
const btnmasuk = document.getElementById("masuk");
smallEmail.classList.add("d-none");
smallPw.classList.add("d-none");
smallNoValid.classList.add("d-none");

btnmasuk.addEventListener('click', () => {
    
    const dataUser = ambilDataUser();
    if (inpEmail === "" || inpPw === "") {
        smallEmail.classList.remove("d-none");
        smallPw.classList.remove("d-none");
        return;
    };
    const ambilUser = dataUser.find((data) => data.emailUser === inpEmail && data.password === inpPw);
    if (!ambilUser) {
        smallEmail.classList.remove("d-none");
         smallPw.classList.add("d-none");
    }

    
});


